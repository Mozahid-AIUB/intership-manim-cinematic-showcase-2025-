from manim import *

class MirrorScene(Scene):
    def construct(self):
        title = Text("Mirror Deployment", font_size=36).to_edge(UP)
        self.play(FadeIn(title))

        # primary mirror hex grid (simplified)
        hexagons = VGroup()
        for i in range(3):
            for j in range(6):
                hexagon = RegularPolygon(n=6, radius=0.4, color="#D4AF37", fill_opacity=1)
                hexagon.shift(RIGHT*j*0.7 + UP*i*0.8)
                hexagons.add(hexagon)

        self.play(FadeIn(hexagons))
        self.wait(1)

        # wing deploy (rotate one part)
        wing = hexagons[-3:].copy()
        self.play(Rotate(wing, angle=PI/2, about_point=wing.get_center()))
        self.wait(1)
