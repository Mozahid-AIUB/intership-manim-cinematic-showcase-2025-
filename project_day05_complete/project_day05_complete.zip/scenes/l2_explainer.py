from manim import *

class L2Scene(Scene):
    def construct(self):
        title = Text("L2 Orbit Explainer", font_size=36).to_edge(UP)
        self.play(FadeIn(title))

        sun = Circle(radius=1, color=YELLOW, fill_opacity=1).shift(LEFT*5)
        earth = Circle(radius=0.5, color=BLUE, fill_opacity=1).shift(ORIGIN)
        l2 = Dot(color=RED).next_to(earth, RIGHT, buff=2)

        self.play(FadeIn(sun), FadeIn(earth), FadeIn(l2))
        self.wait(1)

        label = Tex("JWST at L2").next_to(l2, UP)
        self.play(Write(label))
        self.wait(2)
