from manim import *

class SunshieldScene(Scene):
    def construct(self):
        title = Text("Sunshield Deployment", font_size=36).to_edge(UP)
        self.play(FadeIn(title))

        # ৫টা sunshield layer (rectangle)
        layers = VGroup()
        colors = [GREY, DARK_GREY, GREY_E, LIGHT_GREY, GREY_BROWN]

        for i, c in enumerate(colors):
            rect = Rectangle(width=6+0.3*i, height=3+0.2*i, color=c, fill_opacity=0.5)
            layers.add(rect)

        self.play(LaggedStart(*[FadeIn(layer) for layer in layers], lag_ratio=0.3))
        self.wait(1)
