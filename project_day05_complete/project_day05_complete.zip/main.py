from manim import *
from scenes.sunshield import SunshieldScene
from scenes.mirrors import MirrorScene
from scenes.l2_explainer import L2Scene

class MasterScene(Scene):
    def construct(self):
        # sequential scenes
        for scene_cls in [SunshieldScene, MirrorScene, L2Scene]:
            scene = scene_cls()
            scene.construct()
